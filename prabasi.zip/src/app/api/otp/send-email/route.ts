// app/api/otp/send-email/route.ts
import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const { email } = await request.json();

    // ✅ Validate email
    if (!email) {
      return NextResponse.json(
        { success: false, message: 'Email is required' },
        { status: 400 }
      );
    }

    // ✅ Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { success: false, message: 'Invalid email address' },
        { status: 400 }
      );
    }

    // ✅ Call your backend API
    const formData = new FormData();
    formData.append("email", email);

    const response = await fetch("https://svsamiti.com/prabasiodia/email-otp.php", {
      method: "POST",
      body: formData,
      headers: {
        "Accept": "*/*",
        "User-Agent": "Prabasi-Odia/1.0",
      },
    });

    const data = await response.json();

    // ✅ Return response
    return NextResponse.json({
      success: data.status === true,
      message: data.message || "OTP sent successfully",
    });

  } catch (error) {
    console.error('Send email OTP error:', error);
    return NextResponse.json(
      { success: false, message: 'Failed to send OTP' },
      { status: 500 }
    );
  }
}