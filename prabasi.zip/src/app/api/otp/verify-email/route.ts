// app/api/otp/verify-email/route.ts
import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const { email, otp } = await request.json();

    // ✅ Validate inputs
    if (!email) {
      return NextResponse.json(
        { success: false, message: 'Email is required' },
        { status: 400 }
      );
    }

    if (!otp) {
      return NextResponse.json(
        { success: false, message: 'OTP is required' },
        { status: 400 }
      );
    }

    // ✅ Validate OTP format (6 digits)
    if (!/^\d{6}$/.test(otp)) {
      return NextResponse.json(
        { success: false, message: 'OTP must be 6 digits' },
        { status: 400 }
      );
    }

    // ✅ Call your backend API
    const formData = new FormData();
    formData.append("email", email);
    formData.append("otp", otp);

    const response = await fetch("https://svsamiti.com/prabasiodia/verify-email-otp.php", {
      method: "POST",
      body: formData,
      headers: {
        "Accept": "*/*",
        "User-Agent": "Prabasi-Odia/1.0",
      },
    });

    const data = await response.json();

    // ✅ Return response
    return NextResponse.json({
      success: data.status === true,
      message: data.message || "Email verified successfully",
    });

  } catch (error) {
    console.error('Verify email OTP error:', error);
    return NextResponse.json(
      { success: false, message: 'Failed to verify OTP' },
      { status: 500 }
    );
  }
}