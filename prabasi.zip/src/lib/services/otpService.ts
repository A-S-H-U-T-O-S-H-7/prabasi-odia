// lib/services/otpService.ts

interface SendOtpResponse {
  success: boolean;
  message: string;
}

interface VerifyOtpResponse {
  success: boolean;
  message: string;
}

export const otpService = {
  /**
   * Send OTP to email - Calls our server API route
   */
  async sendEmailOtp(email: string): Promise<SendOtpResponse> {
    try {
      const response = await fetch("/api/otp/send-email", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email }),
      });

      const data = await response.json();
      return {
        success: data.success || false,
        message: data.message || "Failed to send OTP",
      };
    } catch (error) {
      console.error("Send email OTP error:", error);
      return { success: false, message: "Failed to send OTP" };
    }
  },

  /**
   * Verify email OTP - Calls our server API route
   */
  async verifyEmailOtp(email: string, otp: string): Promise<VerifyOtpResponse> {
    try {
      const response = await fetch("/api/otp/verify-email", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, otp }),
      });

      const data = await response.json();
      return {
        success: data.success || false,
        message: data.message || "Failed to verify OTP",
      };
    } catch (error) {
      console.error("Verify email OTP error:", error);
      return { success: false, message: "Failed to verify OTP" };
    }
  },
};